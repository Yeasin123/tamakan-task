@extends('backend.admin_layout')
@section('admin_content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <h2 class="mt-2">Newslater Page</h2>
                <div class="card pd-20 pd-sm-40 mg-t-50 mb-3">
                    <div class="table-wrapper">
                      @if(!$newslater->isEmpty())
                      <table id="datatable1" class="table display responsive nowrap text-center table-bordered">
                        <thead>
                          <tr>
                            <th class="wd-15p">SL</th>
                            <th class="wd-15p">ID</th>
                            <th class="wd-20p">Email</th>
                            <th class="wd-15p">Subscriber Time</th>
                            <th class="wd-10p">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          @php
                          $i = 1;
                        @endphp
                          @foreach ($newslater as $newslaters )
                          <tr>
                            <td>{{$i++}}</td>
                            <td>{{$newslaters->id}}</td>
                            <td>{{$newslaters->email}}</td>
                            <td>{{$newslaters->created_at->diffForHumans()}}</td>
                            <td>
                              <div>
                                <a href="{{route('newslater.destroy', $newslaters->id)}}" class="btn btn-danger" data-toggle="modal" data-target="#newslaterDeleteModal{{$newslaters->id}}">Delete</a>
                              </div>
                            </td>
                          </tr>
                          {{-- Delete Modal --}}
                          <div class="modal fade" id="newslaterDeleteModal{{$newslaters->id}}" tabindex="-1" role="dialog" aria-labelledby="newslaterDeleteModal" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="newslaterDeleteModal">Are you sure to delete this newslater??</h5>
                                  
                                </div>
                                <div class="modal-body text-center">
                                  <form action="{{route('newslater.destroy',$newslaters->id)}}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancle</button>
                                  </form>
                                </div>
                                <div class="modal-footer">
                                  
                                </div>
                              </div>
                            </div>
                          </div>


                          @endforeach
                        </tbody>
                      </table>
                      @else
                        <div class="alert alert-primary" role="alert">
                          <h1 class="text-center">Empty newslater</h1>
                        </div>
                      @endif  
                    </div>
                  </div> 
                

            </div>
        </div>
    </div>
    
@endsection