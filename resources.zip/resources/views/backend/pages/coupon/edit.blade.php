@extends('backend.admin_layout')
@section('admin_content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <h2 class="mt-2">coupon Edit Page</h2>
                <div class="card pd-20 pd-sm-40 mg-t-50 mb-3">
                  <form action="{{route('coupon.update',$coupon->id)}}" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="form-group">
                      <label for="exampleFormControlFile1">Coupon Name</label>
                      <input type="text" value="{{$coupon->coupon}}" class="form-control" name="coupon">
                      @if ($errors->has('coupon'))
                            <span class="invalid feedback"role="alert">
                                <strong class="text-danger">{{ $errors->first('coupon') }}.</strong>
                            </span>
                      @endif
                    </div>
                    <div class="form-group">
                      <label for="exampleFormControlFile1">Discount </label>
                      <input type="text" value="{{$coupon->discount}}" class="form-control" name="discount">
                      @if ($errors->has('discount'))
                            <span class="invalid feedback"role="alert">
                                <strong class="text-danger">{{ $errors->first('discount') }}.</strong>
                            </span>
                      @endif
                    </div>
                   
                    <button type="submit" class="btn btn-primary">store</button>
                  </form>
                  </div>
            </div>
        </div>
    </div>
    
@endsection