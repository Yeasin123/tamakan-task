@extends('backend.admin_layout')
@section('admin_content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <h2 class="mt-2">Brand Edit Page</h2>
                <div class="card pd-20 pd-sm-40 mg-t-50 mb-3">
                  <form action="{{route('brand.update',$brand->id)}}" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="form-group">
                      <label for="exampleFormControlFile1">Brand Name</label>
                      <input type="text" value="{{$brand->name}}" class="form-control" name="name">
                      @error('name')
                      <span class="invalid-feedback text-danger">
                          <strong>{{ $message }}</strong>
                      </span>
                      @enderror
                    </div>
                    <img src="{{asset('images/brand/'.$brand->logo)}}" width="100" alt="">
                    <div class="form-group">
                      <label for="exampleFormControlFile1">Choose Image</label>
                      <input type="file" class="form-control-file" name="logo">
                      @error('logo')
                      <span class="invalid-feedback text-danger">
                          <strong>{{ $message }}</strong>
                      </span>
                      @enderror
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                  </form>
                  </div>
            </div>
        </div>
    </div>
    
@endsection