@extends('backend.admin_layout')
@section('admin_content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <h2 class="mt-2">Brand Create Page</h2>
                <div class="card pd-20 pd-sm-40 mg-t-50 mb-3">
                  <form action="{{route('brand.store')}}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                      <label for="exampleFormControlFile1">Brand Name</label>
                      <input type="text"  class="form-control" name="name">
                      @if ($errors->has('name'))
                            <span class="invalid feedback"role="alert">
                                <strong class="text-danger">{{ $errors->first('name') }}.</strong>
                            </span>
                      @endif
                    </div>
                    <div class="form-group">
                      <label for="exampleFormControlFile1">Choose Image</label>
                      <input type="file" class="form-control-file" name="logo">
                    </div>
                    <button type="submit" class="btn btn-primary">store</button>
                  </form>
                  </div>
            </div>
        </div>
    </div>
    
@endsection