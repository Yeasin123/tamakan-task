@extends('backend.admin_layout')
@section('admin_content')
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h4>Admin Create Page</h4>
      </div>
    </div>
      <div class="row">
          <div class="col-md-12">
            <div class="card pd-20 pd-sm-40 mg-t-50 mb-3">
              <form action="{{route('admin.store')}}" method="POST" >
                @csrf
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="exampleFormControlFile1">Admin Name</label>
                    <input type="text"  class="form-control" name="name">
                    @if ($errors->has('name'))
                          <span class="invalid feedback"role="alert">
                              <strong class="text-danger">{{ $errors->first('name') }}.</strong>
                          </span>
                    @endif
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="exampleFormControlFile1">Admin Phone</label>
                    <input type="text"  class="form-control" name="phone">
                    @if ($errors->has('phone'))
                          <span class="invalid feedback"role="alert">
                              <strong class="text-danger">{{ $errors->first('phone') }}.</strong>
                          </span>
                    @endif
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="exampleFormControlFile1">Admin Email</label>
                    <input type="email"  class="form-control" name="email">
                    @if ($errors->has('email'))
                          <span class="invalid feedback"role="alert">
                              <strong class="text-danger">{{ $errors->first('email') }}.</strong>
                          </span>
                    @endif
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="exampleFormControlFile1">Admin Password</label>
                    <input type="password"  class="form-control" name="password">
                    @if ($errors->has('password'))
                          <span class="invalid feedback"role="alert">
                              <strong class="text-danger">{{ $errors->first('password') }}.</strong>
                          </span>
                    @endif
                  </div>
                </div>
              </div>
              <div class="row mt-3">
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" name="brand">
                    <span>Brand</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" name="category">
                    <span>Category</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" name="coupon">
                    <span>Coupon</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" name="newslater">
                    <span>Newslater</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" name="product">
                    <span>Product</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" name="mainslider">
                    <span>Main Slider</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" name="adminmanagement">
                    <span>Admin Management</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" name="stock">
                    <span>Stock Management</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" name="ordermenagement">
                    <span>Order Management</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" name="orderreport">
                    <span>Report Management</span>
                  </label>
                </div>
             </div>
             <div class="form-group">
              <button type="submit" class="btn btn-info mt-2">Create Admin</button>
            </div>
              </form>
              </div>
          </div>
      </div>
  </div>
@endsection  