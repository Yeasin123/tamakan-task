@extends('backend.admin_layout')
@section('admin_content')
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h4 class="mt-2">Admin Edit Page</h4>
      </div>
    </div>
      <div class="row">
          <div class="col-md-12">
            <div class="card pd-20 pd-sm-40 mg-t-50 mb-3">
              <form action="{{route('admin.update',$admin->id)}}" method="POST" >
                @csrf
                @method('PUT')
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="exampleFormControlFile1">Admin Name</label>
                    <input type="text"  class="form-control" value="{{$admin->name}}" name="name">
                    @if ($errors->has('name'))
                          <span class="invalid feedback"role="alert">
                              <strong class="text-danger">{{ $errors->first('name') }}.</strong>
                          </span>
                    @endif
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="exampleFormControlFile1">Admin Phone</label>
                    <input type="text"  class="form-control" value="{{$admin->phone}}" name="phone">
                    @if ($errors->has('phone'))
                          <span class="invalid feedback"role="alert">
                              <strong class="text-danger">{{ $errors->first('phone') }}.</strong>
                          </span>
                    @endif
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="exampleFormControlFile1">Admin Email</label>
                    <input type="email"  class="form-control" value="{{$admin->email}}" name="email">
                    @if ($errors->has('email'))
                          <span class="invalid feedback"role="alert">
                              <strong class="text-danger">{{ $errors->first('email') }}.</strong>
                          </span>
                    @endif
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="exampleFormControlFile1">Admin Password</label>
                    <input type="password"  class="form-control" value="{{$admin->password}}" name="password">
                    @if ($errors->has('password'))
                          <span class="invalid feedback"role="alert">
                              <strong class="text-danger">{{ $errors->first('password') }}.</strong>
                          </span>
                    @endif
                  </div>
                </div>
              </div>
              <div class="row mt-3">
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" value="{{$admin->brand}}" @if($admin->brand == 1) ? checked : '' @endif name="brand">
                    <span>Brand</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" value="{{$admin->category}}" @if($admin->category == 1) ? checked : '' @endif name="category">
                    <span>Category</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" value="{{$admin->coupon}}" @if($admin->coupon == 1) ? checked : '' @endif name="coupon">
                    <span>Coupon</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" value="{{$admin->newslater}}" @if($admin->newslater == 1) ? checked : '' @endif name="newslater">
                    <span>Newslater</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" value="{{$admin->product}}" @if($admin->product == 1) ? checked : '' @endif name="product">
                    <span>Product</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" value="{{$admin->mainslider}}" @if($admin->mainslider == 1) ? checked : '' @endif name="mainslider">
                    <span>Main Slider</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" value="{{$admin->adminmanagement}}" @if($admin->adminmanagement == 1) ? checked : '' @endif name="adminmanagement">
                    <span>Admin Management</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" value="{{$admin->stock}}" @if($admin->stock == 1) ? checked : '' @endif name="stock">
                    <span>Stock Management</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" value="{{$admin->ordermenagement}}" @if($admin->ordermenagement == 1) ? checked : '' @endif name="ordermenagement">
                    <span>Order Management</span>
                  </label>
                </div>
                <div class="col-md-4">
                  <label class="ckbox">
                    <input type="checkbox" value="1" value="{{$admin->orderreport}}" @if($admin->orderreport == 1) ? checked : '' @endif name="orderreport">
                    <span>Report Management</span>
                  </label>
                </div>
             </div>
             <div class="form-group">
              <button type="submit" class="btn btn-info mt-2">Create Admin</button>
            </div>
              </form>
              </div>
          </div>
      </div>
  </div>
@endsection  