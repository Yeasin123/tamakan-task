@extends('backend.admin_layout')
@section('admin_content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <h2 class="mt-2">Admin manage Page</h2>
                <div class="card pd-20 pd-sm-40 mg-t-50 mb-3">
                  <div><a class="btn btn-success mb-2" style="float:right;cursor:pointer;color:#fff" href="{{route('admin.create')}}">+Create</a></div>
                    <div class="table-wrapper">
                      @if(!$admin->isEmpty())
                      <table id="datatable1" class="table display responsive nowrap text-center table-bordered">
                        <thead>
                          <tr>
                            <th class="wd-15p">SL</th>
                            <th class="wd-15p">Admin Name</th>
                            <th class="wd-20p">Admin Email</th>
                            <th class="wd-20p">Admin Phone</th>
                            <th class="wd-10p">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          @php
                          $i = 1;
                        @endphp
                          @foreach ($admin as $admins )
                          <tr>
                            <td>{{$i++}}</td>
                            <td>{{$admins->name}}</td>
                            <td>{{$admins->email}}</td>
                            <td>{{$admins->phone}}</td>
                            <td>
                              <div class="d-flex justify-content-between">
                                <a href="{{route('admin.edit', $admins->id)}}" class="btn btn-success">Edit</a>
                                <a href="{{route('admin.destroy', $admins->id)}}" class="btn btn-danger" data-toggle="modal" data-target="#adminDeleteModal{{$admins->id}}">Delete</a>
                              </div>
                            </td>
                          </tr>
                          {{-- Delete Modal --}}
                          <div class="modal fade" id="adminDeleteModal{{$admins->id}}" tabindex="-1" role="dialog" aria-labelledby="adminDeleteModal" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="adminDeleteModal">Are you sure to delete this admin??</h5>
                                  
                                </div>
                                <div class="modal-body text-center">
                                  <form action="{{route('admin.destroy',$admins->id)}}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancle</button>
                                  </form>
                                </div>
                                <div class="modal-footer">
                                  
                                </div>
                              </div>
                            </div>
                          </div>


                          @endforeach
                        </tbody>
                      </table>
                      @else
                        <div class="alert alert-primary" role="alert">
                          <h1 class="text-center">Empty Admin</h1>
                        </div>
                      @endif  
                    </div>
                  </div> 
                

            </div>
        </div>
    </div>
    
@endsection