@extends('backend.admin_layout')
@section('admin_content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <h2 class="mt-2">MainSlider Page</h2>
                <div class="card pd-20 pd-sm-40 mg-t-50 mb-3">
                  <div><a class="btn btn-success mb-2" style="float:right;cursor:pointer;color:#fff" href="{{route('mainslider.create')}}">+mainsliders</a></div>
                    <div class="table-wrapper">
                      @if(!$mainsliders->isEmpty())
                      <table id="datatable1" class="table display responsive nowrap text-center table-bordered">
                        <thead>
                          <tr>
                            <th class="wd-15p">SL</th>
                            <th class="wd-15p">Title</th>
                            <th class="wd-20p">Offer</th>
                            <th class="wd-20p">Image</th>
                            <th class="wd-15p">Status</th>
                            <th class="wd-10p">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          @php
                          $i = 1;
                        @endphp
                          @foreach ($mainsliders as $mainslider )
                          <tr>
                            <td>{{$i++}}</td>
                            <td>{{$mainslider->title}}</td>
                            <td>{{$mainslider->offer}}</td>
                            <td><img src="{{ asset('images/mainslider/'. $mainslider->image) }}" width="50" alt="mainsliderslogo"></td>
                            <td>
                              <div>
                                @if($mainslider->status == 1)
                                <span class="badge badge-success">Active</span>
                                @else
                                <span class="badge badge-danger">InActive</span>
                                @endif
                              </div>
                            </td>
                            <td>
                              <div class="d-flex justify-content-between">
                                <a href="{{route('mainslider.edit', $mainslider->id)}}" class="btn btn-success">Edit</a>
                                <a href="{{route('mainslider.destroy', $mainslider->id)}}" class="btn btn-danger" data-toggle="modal" data-target="#mainslidersDeleteModal{{$mainslider->id}}">Delete</a>
                              </div>
                            </td>
                          </tr>
                          {{-- Delete Modal --}}
                          <div class="modal fade" id="mainslidersDeleteModal{{$mainslider->id}}" tabindex="-1" role="dialog" aria-labelledby="mainslidersDeleteModal" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="mainslidersDeleteModal">Are you sure to delete this mainsliders??</h5>
                                  
                                </div>
                                <div class="modal-body text-center">
                                  <form action="{{route('mainslider.destroy',$mainslider->id)}}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancle</button>
                                  </form>
                                </div>
                              </div>
                            </div>
                          </div>
                          @endforeach
                        </tbody>
                      </table>
                      @else
                        <div class="alert alert-primary" role="alert">
                          <h1 class="text-center">Empty MainSlider</h1>
                        </div>
                      @endif  
                    </div>
                  </div> 
                

            </div>
        </div>
    </div>
    
@endsection