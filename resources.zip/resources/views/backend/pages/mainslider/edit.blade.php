@extends('backend.admin_layout')
@section('admin_content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <h2 class="mt-2">Brand Edit Page</h2>
                <div class="card pd-20 pd-sm-40 mg-t-50 mb-3">
                  <form action="{{route('mainslider.update',$mainslider->id)}}" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="form-group">
                      <label for="exampleFormControlFile1">MainSlider Title</label>
                      <input type="text" value="{{$mainslider->title}}" class="form-control" name="title">
                      @error('title')
                      <span class="invalid-feedback text-danger">
                          <strong>{{ $message }}</strong>
                      </span>
                      @enderror
                    </div>
                    <div class="form-group">
                      <label for="exampleFormControlFile1">MainSlider Offer</label>
                      <input type="text" value="{{$mainslider->offer}}" class="form-control" name="offer">
                      @error('offer')
                      <span class="invalid-feedback text-danger">
                          <strong>{{ $message }}</strong>
                      </span>
                      @enderror
                    </div>
                    <img src="{{asset('images/mainslider/'.$mainslider->image)}}" width="100" alt="">
                    <div class="form-group">
                      <label for="exampleFormControlFile1">Choose Image</label>
                      <input type="file" class="form-control-file" name="image">
                      @error('image')
                      <span class="invalid-feedback text-danger">
                          <strong>{{ $message }}</strong>
                      </span>
                      @enderror
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                  </form>
                  </div>
            </div>
        </div>
    </div>
    
@endsection