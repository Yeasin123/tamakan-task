@extends('backend.admin_layout')
@section('admin_content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <h2 class="mt-2">Category Edit Page</h2>
                <div class="card pd-20 pd-sm-40 mg-t-50 mb-3">
                  <form action="{{route('category.update',$category->id)}}" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="form-group">
                      <label for="exampleFormControlFile1">Category Name</label>
                      <input type="text" value="{{$category->name}}" class="form-control" name="name">
                      @error('name')
                      <span class="invalid-feedback text-danger">
                          <strong>{{ $message }}</strong>
                      </span>
                      @enderror
                    </div>
                    <img src="{{asset('images/category/'.$category->photo)}}" width="100" alt="">
                    <div class="form-group">
                      <label for="exampleFormControlFile1">Choose Image</label>
                      <input type="file" class="form-control-file" name="photo">
                      @error('logo')
                      <span class="invalid-feedback text-danger">
                          <strong>{{ $message }}</strong>
                      </span>
                      @enderror
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                  </form>
                  </div>
            </div>
        </div>
    </div>
    
@endsection