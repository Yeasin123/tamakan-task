@extends('backend.admin_layout')
@section('admin_content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <h2 class="mt-2">Product Edit Page</h2>
                <div class="card pd-20 pd-sm-40 mg-t-50 mb-3">
                  <form action="{{route('product.update',$product->id)}}" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                   <div class="row mb-2">
                     <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Product Name</label>
                        <input type="text" value="{{$product->product_name}}" class="form-control" name="product_name">
                        @if ($errors->has('product_name'))
                              <span class="invalid feedback"role="alert">
                                  <strong class="text-danger">{{ $errors->first('product_name') }}.</strong>
                              </span>
                        @endif
                      </div>
                     </div>
                     <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Product Quantity</label>
                        <input type="text" value="{{$product->product_quantity}}"  class="form-control" name="product_quantity">
                        @if ($errors->has('product_quantity'))
                              <span class="invalid feedback"role="alert">
                                  <strong class="text-danger">{{ $errors->first('product_quantity') }}.</strong>
                              </span>
                        @endif
                      </div>
                     </div>
                     <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Category Name</label>
                         <select name="category_id" class="form-control">
                           <option>Choose Category</option>
                           @foreach ($categorys as $category)
                              <option value="{{$category->id}}"  @if($category->id == $product->category->id)  selected @endif >{{$category->name}}</option> 
                           @endforeach
                         </select>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">SubCategory Name</label>
                         <select name="subcategory_id" class="form-control">
                           <option value="">Choose SubCategory</option>
                            @foreach ($subcategorys as $subcategory)
                            <option value="{{$subcategory->id}}"  @if($subcategory->id == $product->subcategory_id)  selected @endif >{{$subcategory->name}}</option> 
                            @endforeach
                         </select>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">ChildCategory Name</label>
                         <select name="childcategory_id" class="form-control">
                          <option value="">Choose ChildCategory</option>
                          @foreach ($childcategorys as $childcategory)
                            <option value="{{$childcategory->id}}"  @if($childcategory->id == $product->childcategory_id)  selected @endif >{{$childcategory->name}}</option> 
                            @endforeach
                         </select>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Brand Name</label>
                         <select name="brand_id" class="form-control">
                           <option value="">Choose Brand</option>
                           @foreach ($brands as $brand)
                           <option value="{{$brand->id}}"  @if($brand->id == $product->brand_id)  selected @endif )>{{$brand->name}}</option>
                           @endforeach
                         </select>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Product Size</label>
                         <input type="text" id="" value="{{$product->product_size}}" data-role="tagsinput" name="product_size" class="form-control multicolor">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Product Color</label>
                         <input type="text" id="" data-role="tagsinput" value="{{$product->product_color}}" name="product_color" class="form-control multicolor">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Buying Price</label>
                        <input type="number" class="form-control" value="{{$product->buying_price}}" name="buying_price">
                        @if ($errors->has('buying_price'))
                              <span class="invalid feedback"role="alert">
                                  <strong class="text-danger">{{ $errors->first('buying_price') }}.</strong>
                              </span>
                        @endif
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Selling Price</label>
                        <input type="number"  value="{{$product->selling_price}}" class="form-control" name="selling_price">
                        @if ($errors->has('selling_price'))
                              <span class="invalid feedback"role="alert">
                                  <strong class="text-danger">{{ $errors->first('selling_price') }}.</strong>
                              </span>
                        @endif
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Discount Price</label>
                        <input type="number" min="1" discount_price class="form-control" value="{{$product->discount_price}}" name="discount_price">
                      </div>
                    </div>
                    <div class="col-md-12">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Video Link</label>
                        <input   class="form-control" value="{{$product->video_link}}" name="video_link" placeholder="Video Link">
                      </div>
                    </div>
                   </div>

                   <div class="row mt-2">
                    <div class="col-md-4">
                      <label class="ckbox">
                        <input type="checkbox" value="1" value="{{$product->main_slider}}" @if($product->mid_slider == 1) ? checked : '' @endif name="main_slider">
                        <span>Main Slider</span>
                      </label>
                    </div>
                    <div class="col-md-4">
                      <label class="ckbox">
                        <input type="checkbox" value="1"  value="{{$product->mid_slider}}" @if($product->mid_slider == 1) ? checked : '' @endif name="mid_slider">
                        <span>Mid Slider</span>
                      </label>
                    </div>
                    <div class="col-md-4">
                      <label class="ckbox">
                        <input type="checkbox" value="1" value="{{$product->hot_deals}}" @if($product->hot_deals == 1) ? checked : '' @endif  name="hot_deals">
                        <span>Hot Deals</span>
                      </label>
                    </div>
                    <div class="col-md-4">
                      <label class="ckbox">
                        <input type="checkbox" value="1" value="{{$product->hot_new}}" @if($product->hot_new == 1) ? checked : '' @endif  name="hot_new">
                        <span>Hot New</span>
                      </label>
                    </div>
                    <div class="col-md-4">
                      <label class="ckbox">
                        <input type="checkbox" value="1" value="{{$product->trend}}" @if($product->trend == 1) ? checked : '' @endif name="trend">
                        <span>Trend</span>
                      </label>
                    </div>
                    <div class="col-md-4">
                      <label class="ckbox">
                        <input type="checkbox" value="1" value="{{$product->best_rated}}" @if($product->best_rated == 1) ? checked : '' @endif name="best_rated">
                        <span>Best Rated</span>
                      </label>
                    </div>
                    <div class="col-md-12 mt-3">
                      <textarea id="summernote" name="product_detials">{{$product->product_detials}}"</textarea>
                    </div>
                    <div class="col-md-12">
                      <div class="form-group mt-3">
                        <button type="submit" class="btn btn-primary">Update</button>
                      </div>
                    </div>
                   </form>
                 </div>
                 

                 <form action="" method="post" enctype="multipart/form-data">
                  @csrf
                  @method('PUT')
                   <div class="row mt-2">
                        <div class="col-md-4">
                          <div class="form-group">
                            <label for="exampleFormControlFile1">Thubnail Image</label>
                            <label class="custom-file">
                              <input type="file" id="file" class="custom-file-input" onchange="readURL(this)" name="image_one">
                              <span class="custom-file-control"></span>
                            </label>
                            <img src="#" id="one" alt="">
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label for="exampleFormControlFile1">Seconde Image</label>
                            <label class="custom-file">
                              <input type="file" id="file" class="custom-file-input" onchange="readURL2(this)" name="image_two">
                              <span class="custom-file-control"></span>
                            </label>
                            <img src="#" id="two" alt="">
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label for="exampleFormControlFile1">Third Image</label>
                            <label class="custom-file">
                              <input type="file" id="file" class="custom-file-input" onchange="readURL3(this)" name="image_three">
                              <span class="custom-file-control"></span>
                            </label>
                            <img src="#" id="three" alt="">
                          </div>
                        </div>

                        <div class="col-md-4">
                          <div class="form-group">
                            <button type="submit" class="btn btn-primary">Update Image</button>
                          </div>
                        </div>
                   </div>
                  </form>
                   
                  </div>
            </div>
        </div>
    </div>
    


<script type="text/javascript">
  function readURL(input){
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function(e) {
        $('#one')
        .attr('src', e.target.result)
        .width(80)
        .height(80);
      };
      reader.readAsDataURL(input.files[0]);
    }
  };
  </script>

  <script type="text/javascript">
  function readURL2(input){
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function(e) {
        $('#two')
        .attr('src', e.target.result)
        .width(80)
        .height(80);
      };
      reader.readAsDataURL(input.files[0]);
    }
  };
</script>

<script type="text/javascript">
  function readURL3(input){
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function(e) {
        $('#three')
        .attr('src', e.target.result)
        .width(80)
        .height(80);
      };
      reader.readAsDataURL(input.files[0]);
    }
  };

</script>
    
@endsection