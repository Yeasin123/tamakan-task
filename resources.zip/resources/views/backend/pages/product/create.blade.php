@extends('backend.admin_layout')
@section('admin_content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <h2 class="mt-2">Product Create Page</h2>
                <div class="card pd-20 pd-sm-40 mg-t-50 mb-3">
                  <form action="{{route('product.store')}}" method="POST" enctype="multipart/form-data">
                    @csrf
                   <div class="row mb-2">
                     <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Product Name</label>
                        <input type="text"  class="form-control" name="product_name">
                        @if ($errors->has('product_name'))
                              <span class="invalid feedback"role="alert">
                                  <strong class="text-danger">{{ $errors->first('product_name') }}.</strong>
                              </span>
                        @endif
                      </div>
                     </div>
                     <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Product Quantity</label>
                        <input type="text"  class="form-control" name="product_quantity">
                        @if ($errors->has('product_quantity'))
                              <span class="invalid feedback"role="alert">
                                  <strong class="text-danger">{{ $errors->first('product_quantity') }}.</strong>
                              </span>
                        @endif
                      </div>
                     </div>
                     <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Category Name</label>
                         <select name="category_id" class="form-control">
                           <option>Choose Category</option>
                           @foreach ($categorys as $category)
                              <option value="{{$category->id}}">{{$category->name}}</option> 
                           @endforeach
                         </select>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">SubCategory Name</label>
                         <select name="subcategory_id" class="form-control">
                           <option value="">Choose SubCategory</option>
                          
                         </select>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">ChildCategory Name</label>
                         <select name="childcategory_id" class="form-control">
                          <option value="">Choose ChildCategory</option>
                         </select>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Brand Name</label>
                         <select name="brand_id" class="form-control">
                           <option value="">Choose Brand</option>
                           @foreach ($brands as $brand)
                               <option value="{{$brand->id}}">{{$brand->name}}</option>
                           @endforeach
                         </select>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Product Color</label>
                         <input type="text" id="" data-role="tagsinput" name="product_color" class="form-control multicolor">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Product Size</label>
                         <input type="text" id="" data-role="tagsinput" name="product_size" class="form-control multicolor">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Buying Price</label>
                        <input type="number" min="1"  class="form-control" name="buying_price">
                        @if ($errors->has('buying_price'))
                              <span class="invalid feedback"role="alert">
                                  <strong class="text-danger">{{ $errors->first('buying_price') }}.</strong>
                              </span>
                        @endif
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Selling Price</label>
                        <input type="number" min="1"  class="form-control" name="selling_price">
                        @if ($errors->has('selling_price'))
                              <span class="invalid feedback"role="alert">
                                  <strong class="text-danger">{{ $errors->first('selling_price') }}.</strong>
                              </span>
                        @endif
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Discount Price</label>
                        <input type="number" min="1"  class="form-control" name="discount_price">
                      </div>
                    </div>
                    <div class="col-md-12">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Video Link</label>
                        <input   class="form-control"  name="video_link" placeholder="Video Link">
                      </div>
                    </div>

                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Thubnail Image</label>
                        <label class="custom-file">
                          <input type="file" id="file" class="custom-file-input" onchange="readURL(this)" name="image_one">
                          <span class="custom-file-control"></span>
                        </label>
                        <img src="#" id="one" alt="">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Seconde Image</label>
                        <label class="custom-file">
                          <input type="file" id="file" class="custom-file-input" onchange="readURL2(this)" name="image_two">
                          <span class="custom-file-control"></span>
                        </label>
                        <img src="#" id="two" alt="">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="exampleFormControlFile1">Third Image</label>
                        <label class="custom-file">
                          <input type="file" id="file" class="custom-file-input" onchange="readURL3(this)" name="image_three">
                          <span class="custom-file-control"></span>
                        </label>
                        <img src="#" id="three" alt="">
                      </div>
                    </div>

                   </div>

                   <div class="row mt-3">
                      <div class="col-md-4">
                        <label class="ckbox">
                          <input type="checkbox" value="1" name="main_slider">
                          <span>Main Slider</span>
                        </label>
                      </div>
                      <div class="col-md-4">
                        <label class="ckbox">
                          <input type="checkbox" value="1" name="mid_slider">
                          <span>Mid Slider</span>
                        </label>
                      </div>
                      <div class="col-md-4">
                        <label class="ckbox">
                          <input type="checkbox" value="1" name="hot_deals">
                          <span>Hot Deals</span>
                        </label>
                      </div>
                      <div class="col-md-4">
                        <label class="ckbox">
                          <input type="checkbox" value="1" name="hot_new">
                          <span>Hot New</span>
                        </label>
                      </div>
                      <div class="col-md-4">
                        <label class="ckbox">
                          <input type="checkbox" value="1" name="trend">
                          <span>Trend</span>
                        </label>
                      </div>
                      <div class="col-md-4">
                        <label class="ckbox">
                          <input type="checkbox" value="1" name="best_rated">
                          <span>Best Rated</span>
                        </label>
                      </div>
                      <div class="col-md-12 mt-3">
                        <textarea id="summernote" name="product_detials"></textarea>
                      </div>
                   </div>
                   <div class="form-group mt-3">
                     <button type="submit" class="btn btn-primary">Submit</button>
                   </div>
                  </form>
                  </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
    <script type="text/javascript">
      $(document).ready(function(){
        
     $('select[name="category_id"]').on('change',function(){
          var category_id = $(this).val();
          if (category_id) {
            
            $.ajax({
              url: "{{ url('/admin/get/subcategory/') }}/"+category_id,
              type:"GET",
              dataType:"json",
              success:function(data) { 
              var d =$('select[name="subcategory_id"]').empty();
              $.each(data, function(key, value){
              
              $('select[name="subcategory_id"]').append('<option value="'+ value.id + '">' + value.name + '</option>');

              });
              },
            });

          }

        });

            $('select[name="subcategory_id"]').on('change',function(){
      var subcategory_id = $(this).val();
      if (subcategory_id) {
        
        $.ajax({
          url: "{{ url('/admin/get/childcategory/') }}/"+subcategory_id,
          type:"GET",
          dataType:"json",
          success:function(data) { 
          var d =$('select[name="childcategory_id"]').empty();
          $.each(data, function(key, value){
          
          $('select[name="childcategory_id"]').append('<option value="'+ value.id + '">' + value.name + '</option>');

          });
          },
        });

      }

        });
      });

 </script>


<script type="text/javascript">
  function readURL(input){
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function(e) {
        $('#one')
        .attr('src', e.target.result)
        .width(80)
        .height(80);
      };
      reader.readAsDataURL(input.files[0]);
    }
  };
  </script>

  <script type="text/javascript">
  function readURL2(input){
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function(e) {
        $('#two')
        .attr('src', e.target.result)
        .width(80)
        .height(80);
      };
      reader.readAsDataURL(input.files[0]);
    }
  };
</script>

<script type="text/javascript">
  function readURL3(input){
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function(e) {
        $('#three')
        .attr('src', e.target.result)
        .width(80)
        .height(80);
      };
      reader.readAsDataURL(input.files[0]);
    }
  };

</script>
    
@endsection