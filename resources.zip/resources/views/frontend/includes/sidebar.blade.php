
    <div class="catagory-sidebar-area">
        <div class="catagory-sidebar-area-inner">
            <div class="catagory-sidebar all-catagory-option">
                <ul class="cat_menu">
                    @foreach (App\Models\Category::orderBy('id','desc')->get() as $maincate)
                    <li class="hassubs">
                        <a href="{{route('maincatproduct',$maincate->slug)}}">{{$maincate->name}}<i class="fas fa-chevron-right"></i></a>
                        <ul class="moblie_menus">
                            @foreach (App\Models\SubCategory::orderBy('id','desc')->where('category_id',$maincate->id)->get() as $subcate)
                            <li class="hassubs">
                                <a href="{{route('subcatproduct',$subcate->slug)}}">{{$subcate->name}}</a>
                                <ul>
                                    @foreach (App\Models\ChildCategory::orderBy('id','desc')->where('subcategory_id',$subcate->id)->get() as $childcate)
                                   
                                    <li><a href="{{route('childcatproduct',$childcate->slug)}}">{{$childcate->name}}<i class="fas fa-chevron-right"></i></a></li>
                                    @endforeach
                                </ul>
                            </li>
                            @endforeach
                        </ul>
                    </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
