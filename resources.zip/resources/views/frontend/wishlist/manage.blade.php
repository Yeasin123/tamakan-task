@extends('frontend.user_layout')

@section('main_content')
    <section class="wishlist">
        <div class="container">
            <div class="row">
              <div class="col-md-12">
                <h2 class="text-center mt-3">Wishlist Product</h2>
            </div>
                <div class="col-md-10 offset-md-1">
                  @if(!$wishlists->isEmpty())
                    <div class="wislist_table">
                        <table class="table table-bordered text-center table-responsive-sm">
                            <thead>
                              <tr>
                                <th scope="col">SL</th>
                                <th scope="col">Image</th>
                                <th scope="col">Product name</th>
                                <th scope="col">Price</th>
                                <th scope="col">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              @php
                                $i=1;  
                              @endphp
                              @foreach ($wishlists as $wishlist)
                              <tr class="wishTR">
                                <td>{{$i++}}</td>
                                <td>
                                  <a href="{{route('productdetail',$wishlist->product_id)}}">
                                    <img src="{{asset('images/product/'.$wishlist->product->image_one)}}" width="50" height="35" alt="product">
                                  </a>
                                </td>
                                <td>{{$wishlist->product->product_name}}</td>
                                <td>{{$wishlist->product->selling_price}}</td>
                                <td>
                                  <div class="d-flex justify-content-center">
                                    <a  class="btn btn-danger btn-sm text-white wishlistDelete" data-id="{{$wishlist->id}}">Delete</a>
                                  </div>
                                </td>
                              </tr>
                            
                              @endforeach
                              
                            </tbody>
                          </table>
                    </div>
                    @else
                    <section class="error-page text-center">
                      <div class="container">
                          <h1>404</h1>
                          <p>It looks like nothing was found at this location.</p>
                          <a href="{{route('userHome')}}" class="backhome">Back Home</a>
                      </div>
                  </section>
                    @endif
                </div>
            </div>
        </div>
    </section>
@endsection