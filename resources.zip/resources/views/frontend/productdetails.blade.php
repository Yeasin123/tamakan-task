@extends('frontend.user_layout')
@section('main_content')
    {{-- <section class="product-zoom-info-section section-ptb">
    <div class="container">
        <div class="product-zoom-info-container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="product-zoom-area">
                        <span class="batch">30%</span>
                            <div class="product-slick slick-initialized slick-slider">
                                <div class="slick-list draggable">
                                    <div class="slick-track" style="opacity: 1; width: 1996px;">
                                        <div class="slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" style="width: 499px; position: relative; left: 0px; top: 0px; z-index: 999; opacity: 1;">
                                            <div>
                                                <div style="width: 100%; display: inline-block;">
                                                    <img src="{{asset('images/product/'.$product->image_one)}}" alt="" class="img-fluid blur-up lazyload image_zoom_cls-0">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" style="width: 499px; position: relative; left: -499px; top: 0px; z-index: 998; opacity: 0;">
                                            <div>
                                                <div style="width: 100%; display: inline-block;">
                                                    <img src="{{asset('images/product/'.$product->image_two)}}" alt="" class="img-fluid blur-up lazyload image_zoom_cls-1">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="slick-slide" data-slick-index="2" aria-hidden="true" tabindex="-1" style="width: 499px; position: relative; left: -998px; top: 0px; z-index: 998; opacity: 0;">
                                            <div>
                                                <div style="width: 100%; display: inline-block;">
                                                    <img src="{{asset('images/product/'.$product->image_one)}}" alt="" class="img-fluid blur-up lazyload image_zoom_cls-2">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="slider-nav slick-initialized slick-slider"><div class="slick-list draggable" style="padding: 0px 50px;"><div class="slick-track" style="opacity: 1; width: 400px; transform: translate3d(0px, 0px, 0px);"><div class="slick-slide slick-current slick-center" data-slick-index="0" aria-hidden="true" style="width: 100px;"><div><div style="width: 100%; display: inline-block;"><img src="assets/images/product-detail/01.jpg" alt="" class="img-fluid blur-up lazyload"></div></div></div><div class="slick-slide" data-slick-index="1" aria-hidden="true" style="width: 100px;"><div><div style="width: 100%; display: inline-block;"><img src="assets/images/product-detail/02.jpg" alt="" class="img-fluid blur-up lazyload"></div></div></div><div class="slick-slide" data-slick-index="2" aria-hidden="true" style="width: 100px;"><div><div style="width: 100%; display: inline-block;"><img src="assets/images/product-detail/03.jpg" alt="" class="img-fluid blur-up lazyload"></div></div></div><div class="slick-slide slick-center" data-slick-index="3" aria-hidden="true" style="width: 100px;"><div><div style="width: 100%; display: inline-block;"><img src="assets/images/product-detail/01.jpg" alt="" class="img-fluid blur-up lazyload"></div></div></div></div></div></div>
                                </div>
                            </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    
                    <div class="product-details-content">
                        <a class="wish-link addWishlist" href="#" data-id="{{$product->id}}">
                            <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="heart" class="svg-inline--fa fa-heart fa-w-16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M462.3 62.6C407.5 15.9 326 24.3 275.7 76.2L256 96.5l-19.7-20.3C186.1 24.3 104.5 15.9 49.7 62.6c-62.8 53.6-66.1 149.8-9.9 207.9l193.5 199.8c12.5 12.9 32.8 12.9 45.3 0l193.5-199.8c56.3-58.1 53-154.3-9.8-207.9z"></path></svg>
                        </a>
                        <p>{{$product->category->name}} > @if ($product->subcategory->name == null)  @else {{$product->subcategory->name}} > @endif  @if ($product->childcategory === null) @else {{$product->childcategory->name}} @endif </p>
                        <h2>{{$product->product_name}}</h2>
                        <p class="quantity">{{$product->product_quantity}}</p>
                        @if ($product->discount_price == null)
                        <div class="price">{{$product->selling_price}} ৳</div>
                        @else 
                            <div class="price">{{$product->discount_price}} ৳<del>{{$product->selling_price}} ৳</del></div>
                        @endif
                        <div class="">
                            
                                <div class="row">
                                    @if ($product->product_size !== null)
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label for="">Size</label>
                                            <select name="size" class="form-control">
                                                <option value="">Size</option>
                                                @foreach ($sizes as $size)
                                                <option value="{{$size}}">{{$size}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    @else
                                    @endif
                                    @if ($product->product_color !== null)
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="">Color</label>
                                            <select name="color" class="form-control">
                                                <option value="">Color</option>
                                                @foreach ($colors as $color)
                                                <option value="{{$color}}">{{$color}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    @else
                                    @endif
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="">Quantity</label>
                                            <input type="number" min="1" value="1" width="40" name="product_quantity" class="form-control">
                                        </div>
                                    </div>
                                </div>
                        </div>
                        <p>{!!  substr(strip_tags($product->product_detials), 0, 150) !!}</p>
                        <div class="d-flex justify-content-end">
                            <button type="submit" class="buy-now text-white addToCart" data-id="{{$product->id}}">add to cart</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> --}}

    <section class="product-zoom-info-section section-ptb">
        <div class="container">
            <div class="product-zoom-info-container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="product-zoom-area">
                            <div class="product-slick slick-initialized slick-slider">
                                <div class="slick-list draggable">
                                    <div class="slick-track" style="opacity: 1; width: 1996px;">
                                        <div class="slick-slide" data-slick-index="0" aria-hidden="true"
                                            style="width: 499px; position: relative; left: 0px; top: 0px; z-index: 998; opacity: 0; transition: opacity 500ms ease 0s;"
                                            tabindex="-1">
                                            <div>
                                                <div style="width: 100%; display: inline-block;"><img src="{{asset('images/product/'.$product->image_one)}}" alt="" class="img-fluid blur-up lazyload image_zoom_cls-0"></div>
                                            </div>
                                        </div>
                                        <div class="slick-slide slick-current slick-active" data-slick-index="1"
                                            aria-hidden="false"
                                            style="width: 499px; position: relative; left: -499px; top: 0px; z-index: 999; opacity: 1;">
                                            <div>
                                                <div style="width: 100%; display: inline-block;"><img
                                                        src="{{asset('images/product/'.$product->image_one)}}"
                                                        alt="" class="img-fluid blur-up lazyload image_zoom_cls-1"></div>
                                            </div>
                                        </div>
                                        <div class="slick-slide" data-slick-index="2" aria-hidden="true" tabindex="-1"
                                            style="width: 499px; position: relative; left: -998px; top: 0px; z-index: 998; opacity: 0;">
                                            <div>
                                                <div style="width: 100%; display: inline-block;"><img
                                                        src="{{asset('images/product/'.$product->image_one)}}" alt=""
                                                        class="img-fluid blur-up lazyload image_zoom_cls-2"></div>
                                            </div>
                                        </div>
                                        <div class="slick-slide" data-slick-index="3" aria-hidden="true" tabindex="-1"
                                            style="width: 499px; position: relative; left: -1497px; top: 0px; z-index: 998; opacity: 0;">
                                            <div>
                                                <div style="width: 100%; display: inline-block;"><img
                                                        src="{{asset('images/product/'.$product->image_one)}}" alt=""
                                                        class="img-fluid blur-up lazyload image_zoom_cls-3"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="slider-nav slick-initialized slick-slider">
                                        <div class="slick-list draggable" style="padding: 0px 50px;">
                                            <div class="slick-track"
                                                style="opacity: 1; width: 400px; transform: translate3d(-100px, 0px, 0px);">
                                                <div class="slick-slide" data-slick-index="0" aria-hidden="true"
                                                    style="width: 100px;" tabindex="-1">
                                                    <div>
                                                        <div style="width: 100%; display: inline-block;">
                                                            <img src="{{asset('images/product/'.$product->image_two)}}" alt=""
                                                                class="img-fluid blur-up lazyload">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="slick-slide slick-current slick-center" data-slick-index="1"
                                                    aria-hidden="true" style="width: 100px;">
                                                    <div>
                                                        <div style="width: 100%; display: inline-block;">
                                                            <img src="{{asset('images/product/'.$product->image_one)}}"
                                                                alt="" class="img-fluid blur-up lazyload">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="slick-slide" data-slick-index="2" aria-hidden="true"
                                                    style="width: 100px;">
                                                    <div>
                                                        <div style="width: 100%; display: inline-block;">
                                                            <img src="{{asset('images/product/'.$product->image_one)}}" alt=""
                                                                class="img-fluid blur-up lazyload">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="slick-slide" data-slick-index="3" aria-hidden="true"
                                                    style="width: 100px;">
                                                    <div>
                                                        <div style="width: 100%; display: inline-block;">
                                                            <img src="{{asset('images/product/'.$product->image_one)}}" alt=""
                                                                class="img-fluid blur-up lazyload">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="product-details-content">
                            <a class="wish-link addWishlist" href="#" data-id="{{$product->id}}">
                                <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="heart" class="svg-inline--fa fa-heart fa-w-16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M462.3 62.6C407.5 15.9 326 24.3 275.7 76.2L256 96.5l-19.7-20.3C186.1 24.3 104.5 15.9 49.7 62.6c-62.8 53.6-66.1 149.8-9.9 207.9l193.5 199.8c12.5 12.9 32.8 12.9 45.3 0l193.5-199.8c56.3-58.1 53-154.3-9.8-207.9z"></path></svg>
                            </a>
                            <p>{{$product->category->name}} > @if ($product->subcategory->name == null)  @else {{$product->subcategory->name}} > @endif  @if ($product->childcategory === null) @else {{$product->childcategory->name}} @endif </p>
                            <h2>{{$product->product_name}}</h2>
                            <p class="quantity">Available Stock {{$product->product_quantity}}</p>
                            @if ($product->discount_price == null)
                            <div class="price">{{$product->selling_price}} ৳</div>
                            @else 
                                <div class="price">{{$product->discount_price}} ৳<del>{{$product->selling_price}} ৳</del></div>
                            @endif
                            <div class="">
                                
                                    <div class="row">
                                        @if ($product->product_size !== null)
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label for="">Size</label>
                                                <select name="size" class="form-control">
                                                    <option value="">Size</option>
                                                    @foreach ($sizes as $size)
                                                    <option value="{{$size}}">{{$size}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        @else
                                        @endif
                                        @if ($product->product_color !== null)
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="">Color</label>
                                                <select name="color" class="form-control">
                                                    <option value="">Color</option>
                                                    @foreach ($colors as $color)
                                                    <option value="{{$color}}">{{$color}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        @else
                                        @endif
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Quantity</label>
                                                <input type="number" min="1" value="1" width="40" name="product_quantity" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <p>{!!  substr(strip_tags($product->product_detials), 0, 150) !!}</p>
                            <div class="d-flex justify-content-end">
                                <button type="submit" class="buy-now text-white addToCart" data-id="{{$product->id}}">add to cart</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
