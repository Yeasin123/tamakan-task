@extends('frontend.user_layout')
@section('main_content')

<section class="dashboard-section">
  <div class="container">
      <div class="row">
          <div class="col-lg-6">
              <div class="cart-item sitebar-cart bg-color-white box-shadow p-3 mb-3 p-lg-5 border-radius5">
                  <div class="cart-footer">
                      
                      <div class="cart-total">
                          @foreach (Cart::content() as $item)
                          <p class="saving d-flex justify-content-between">
                              <span>Product Name:  <a href="{{route('couponremove')}}">{{$item->name}}</a></span> 
                              <span>{{$item->price}} ৳</span>
                          </p>
                          <p class="saving d-flex justify-content-between">
                              <span>Qty: </span> 
                              <span>{{$item->qty}}</span>
                          </p>
                          @endforeach
                      </div>
                      <div class="cart-total">
                        @if(Session::has('coupon'))
                          <p class="saving d-flex justify-content-between">
                              <span>Coupon [{{Session::get('coupon')['name']}}] <a href="{{route('couponremove')}}"><i class="fas fa-trash"></i></a></span> 
                              <span>{{Session::get('coupon')['discount']}} ৳</span>
                          </p>
                          @else
                          @endif
                          @if(Session::has('coupon'))
                          <p class="saving d-flex justify-content-between">
                              <span>Total Saving</span> 
                              <span>{{Cart::total()}}  - <span>{{Session::get('coupon')['discount']}} ৳</span>
                              <p class="text-right" style="color:#59B863;font-weight:600">{{Session::get('coupon')['balance']}} ৳</p>
                          </p>
                          @else
                          @endif
                          <p class="total-price d-flex justify-content-between">
                              <span>Total</span> 
                              @if(Session::has('coupon'))
                              <span>{{Session::get('coupon')['balance']}} ৳</span>
                              @else
                              <span>{{Cart::total()}} ৳</span>
                              @endif
                          </p>
                      </div>
                  </div>
              </div>

           
          </div>
          <div class="col-md-6">
            <div class="stripes">
              <form id="payment-form" action="{{route('stripe.payment')}}" method="post">
                @csrf

                <input type="hidden" name="name" value="{{$data['name']}}">
                <input type="hidden" name="area" value="{{$data['area']}}">
                <input type="hidden" name="city_name" value="{{$data['city_name']}}">
                <input type="hidden" name="payment_type" value="{{$data['payment']}}">
                <input type="hidden" name="address" value="{{$data['address']}}">
                <input type="hidden" name="email" value="{{$data['email']}}">
                <input type="hidden" name="phone" value="{{$data['phone']}}">
                <input type="hidden" name="order_note" value="{{$data['order_note']}}">
                <div id="card-element"></div><br>
                <button id="card-button" class="btn btn-dark">Submit Payment</button>
                <p id="payment-result"></p>
              </form>
            </div>
          </div>
      </div>
  </div>
</section>

<script>
    var form = document.getElementById('payment-form');

    var resultContainer = document.getElementById('payment-result');
    cardElement.on('change', function(event) {
      if (event.error) {
        resultContainer.textContent = event.error.message;
      } else {
        resultContainer.textContent = '';
      }
    });

    form.addEventListener('submit', function(event) {
      event.preventDefault();
      resultContainer.textContent = "";
      stripe.createPaymentMethod({
        type: 'card',
        card: cardElement,
      }).then(handlePaymentMethodResult);
    });

    function handlePaymentMethodResult(result) {
      if (result.error) {
        // An error happened when collecting card details, show it in the payment form
        resultContainer.textContent = result.error.message;
      } else {
        // Otherwise send paymentMethod.id to your server (see Step 3)
        fetch('/pay', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ payment_method_id: result.paymentMethod.id })
        }).then(function(result) {
          return result.json();
        }).then(handleServerResponse);
      }
    }

  function handleServerResponse(responseJson) {
    if (responseJson.error) {
      // An error happened when charging the card, show it in the payment form
      resultContainer.textContent = responseJson.error;
    } else {
      // Show a success message
      resultContainer.textContent = 'Success!';
    }
  }
</script>

@endsection