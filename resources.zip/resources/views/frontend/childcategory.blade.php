@extends('frontend.user_layout')

@section('main_content')
@if(!$childcategorys->isEmpty())
<section class="page-content section-ptb-90">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="row product-list">
                   @foreach ($childcategorys as $childcategory)
                   <div class="col-sm-6 col-lg-4 col-xl-3 col-6" style="display: block;">
                    <div class="product-item">
                        <div class="product-thumb">
                            <a href="{{route('childcatproduct',$childcategory->slug)}} "><img src="{{asset('images/childcategory/'.$childcategory->photo)}}" alt="childcategory"></a>
                            <p class="catagory-name">{{$childcategory->name}} </p>
                        </div>
                    </div>
                </div>
                    @endforeach
                   
                    <div class="col-12 text-center d-flex justify-content-center mt-4">
                        {{$childcategorys->links()}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@else
<section class="error-page text-center">
    <div class="container">
        <h1>404</h1>
        <p>It looks like nothing was found at this location.</p>
        <a href="{{route('userHome')}}" class="backhome">Back To Home</a>
    </div>
</section>

@endif

@endsection