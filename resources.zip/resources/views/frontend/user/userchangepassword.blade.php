@extends('frontend.user_layout')

@section('main_content')

<section class="page-content section-ptb-90">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3 class=" mb-1">Change Your Password</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-7">
                <div class="passwordChange">
                    <form action="{{route('userPasswordChange')}}" method="POST" >
                        @csrf
                        <div class="form-group">
                            <label>Your Old Password</label>
                            <input type="password" class="form-control" name="oldpassword">
                        </div>
                        <div class="form-group">
                            <label >New Password</label>
                            <input type="password" class="form-control" name="password">
                         </div>
                         <div class="form-group">
                            <label >Confirm Password</label>
                            <input type="password" class="form-control" name="password_confirmation">
                        </div>
                        <div class="form-group">
                            <label >Avatar</label>
                            <input type="file" class="form-control-file" name="image">
                          </div>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                     </form>
                </div>
            </div>

            <div class="col-lg-5">
              <div class="dashboard-body">
                <div class="profile">
                    <h5 class="title">Your Profile <a href="{{route('userProfileUpdate',Auth::user()->id)}}" data-toggle="modal" data-target="#exampleModal{{Auth::user()->id}}"><span title="Edit Profile" class="edit" ><i class="fas fa-edit"></i></span></a></h5>
                    <ul class="list-profile-info list-unstyled">
                        <li>
                            @if(Auth::user()->image !== NULL)
                            <img src="{{asset('images/user/'.Auth::user()->image)}}" width="40" alt="avatar">
                            @else
                            <img src="{{asset('images/avatar.png')}}" alt="">
                            @endif
                        </li>
                        <li>
                            <span class="title">Your Name</span>
                            <span class="desc">{{Auth::user()->name}}</span>
                        </li>
                        <li>
                            <span class="title">Email</span>
                            <span class="desc">{{Auth::user()->email}}</span>
                        </li>
                        <li>
                            <span class="title">Phone</span>
                            <span class="desc">{{Auth::user()->phone}}</span>
                        </li>
                        <li>
                            <span class="title">Password</span>
                            <span class="desc"><strong><a href="{{route('userPassword')}}">Change Password</a></strong></span>
                        </li>
                        <li>
                            <span class="title">
                                <a href="{{ route('logout') }}" class="btn btn-info"
                                    onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                                    {{ __('Logout') }}
                            </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                @csrf
                            </form>
                            </span>
                        </li>
                    </ul>

                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal{{Auth::user()->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModal" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                            <h5 class="modal-title" id="exampleModal">Edit Profile</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
                            <div class="modal-body">
                                <form action="{{route('userProfileUpdate',Auth::user()->id)}}" method="POST" >
                                    @csrf
                                    <div class="form-group">
                                      <label>Name</label>
                                      <input type="text" class="form-control" name="name" value="{{Auth::user()->name}}">
                                    </div>
                                    <div class="form-group">
                                        <label >Email</label>
                                        <input type="email" class="form-control" name="email" value="{{Auth::user()->email}}">
                                      </div>
                                      <div class="form-group">
                                        <label >Phone</label>
                                        <input type="text" class="form-control" name="phone" value="{{Auth::user()->phone}}">
                                      </div>
                                      <input type="hidden" name="password" value="{{Auth::user()->password}}">
                                    <button type="submit" class="btn btn-primary">Save changes</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancle</button>
                                  </form>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
              </div>
            </div>
        </div>
   </div>
</section>

@endsection