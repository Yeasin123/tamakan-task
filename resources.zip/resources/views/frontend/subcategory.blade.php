@extends('frontend.user_layout')

@section('main_content')
@if(!$subcategorys->isEmpty())
<section class="page-content section-ptb-90">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="row product-list">
                   @foreach ($subcategorys as $subcategory)
                    <div class="col-sm-6 col-lg-4 col-xl-3 col-6" style="display: block;">
                        <div class="product-item">
                            @if($subcategory->childcategory->count() > 0)
                            <div class="product-thumb">
                                <a href="{{route('childcategory',$subcategory->slug)}} "><img src="{{asset('images/subcategory/'.$subcategory->photo)}}" alt="subcategory"></a>
                                <p class="catagory-name">{{$subcategory->name}} </p>
                            </div>
                            @else
                            <div class="product-content text-center">
                                <a href="{{route('subcatproduct',$subcategory->slug)}} "><img src="{{asset('images/subcategory/'.$subcategory->photo)}}" alt="subcategory"></a>
                                <p class="catagory-name">{{$subcategory->name}} </p>
                            </div>
                            @endif
                        </div>
                    </div>
                    @endforeach
                   
                    <div class="col-12 text-center d-flex justify-content-center mt-4">
                        {{$subcategorys->links()}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@else
<section class="error-page text-center">
    <div class="container">
        <h1>404</h1>
        <p>It looks like nothing was found at this location.</p>
        <a href="{{route('userHome')}}" class="backhome">Back To Home</a>
    </div>
</section>

@endif

@endsection